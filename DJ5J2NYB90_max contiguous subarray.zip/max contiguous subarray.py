list_a = list(map(int, input().split()))

length_list = len(list_a)

if length_list == 0:
    print("0")
else:
    dict_list_a = {}
    for i in range(length_list):
        for j in range(i+1,length_list+1):
            keys = tuple(list_a[i:j])
            values = sum(list_a[i:j])
            dict_list_a[keys] = values
            keys_list = list(dict_list_a.keys())
            value_list = list(dict_list_a.values())
    max_index_value = value_list.index(max(value_list))        
    print(*keys_list[max_index_value])